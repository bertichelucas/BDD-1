-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema DHespegar
-- -----------------------------------------------------

-- -----------------------------------------------------
-- Schema DHespegar
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `DHespegar` DEFAULT CHARACTER SET utf8 ;
USE `DHespegar` ;

-- -----------------------------------------------------
-- Table `DHespegar`.`Pais`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Pais` (
  `idPais` INT NOT NULL,
  `nombre` VARCHAR(45) NULL,
  PRIMARY KEY (`idPais`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Ciudad`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Ciudad` (
  `idCiudad` INT NOT NULL,
  `nombre` VARCHAR(45) NULL,
  `Pais_idPais` INT NOT NULL,
  PRIMARY KEY (`idCiudad`),
  INDEX `fk_Ciudad_Pais1_idx` (`Pais_idPais` ASC) VISIBLE,
  CONSTRAINT `fk_Ciudad_Pais1`
    FOREIGN KEY (`Pais_idPais`)
    REFERENCES `DHespegar`.`Pais` (`idPais`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Sucursal`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Sucursal` (
  `idSucursales` INT NOT NULL,
  `telefono` INT NULL,
  `direccion` VARCHAR(45) NULL,
  `Ciudad_idCiudad` INT NOT NULL,
  PRIMARY KEY (`idSucursales`),
  INDEX `fk_Sucursal_Ciudad1_idx` (`Ciudad_idCiudad` ASC) VISIBLE,
  CONSTRAINT `fk_Sucursal_Ciudad1`
    FOREIGN KEY (`Ciudad_idCiudad`)
    REFERENCES `DHespegar`.`Ciudad` (`idCiudad`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Cliente`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Cliente` (
  `idCliente` INT NOT NULL,
  `nombre` VARCHAR(50) NULL,
  `apellido` VARCHAR(50) NULL,
  `nro_pasaporte` VARCHAR(20) NULL,
  `direccion` VARCHAR(45) NULL,
  `telefono` INT NULL,
  `Ciudad_idCiudad` INT NOT NULL,
  PRIMARY KEY (`idCliente`),
  INDEX `fk_Cliente_Ciudad1_idx` (`Ciudad_idCiudad` ASC) VISIBLE,
  CONSTRAINT `fk_Cliente_Ciudad1`
    FOREIGN KEY (`Ciudad_idCiudad`)
    REFERENCES `DHespegar`.`Ciudad` (`idCiudad`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Pago`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Pago` (
  `idPago` INT NOT NULL,
  `metodo_de_pago` VARCHAR(45) NULL,
  `cant_cuotas` TINYINT NULL,
  `precio` FLOAT NULL,
  PRIMARY KEY (`idPago`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Reserva`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Reserva` (
  `idReserva` INT NOT NULL,
  `codigo_reserva` CHAR(6) NULL,
  `fecha_hora_registro` DATETIME NULL,
  `Pago_idPago` INT NOT NULL,
  `Cliente_idCliente` INT NOT NULL,
  `Sucursal_idSucursales` INT NOT NULL,
  PRIMARY KEY (`idReserva`),
  INDEX `fk_Reserva_Pago1_idx` (`Pago_idPago` ASC) VISIBLE,
  INDEX `fk_Reserva_Cliente1_idx` (`Cliente_idCliente` ASC) VISIBLE,
  INDEX `fk_Reserva_Sucursal1_idx` (`Sucursal_idSucursales` ASC) VISIBLE,
  CONSTRAINT `fk_Reserva_Pago1`
    FOREIGN KEY (`Pago_idPago`)
    REFERENCES `DHespegar`.`Pago` (`idPago`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Reserva_Cliente1`
    FOREIGN KEY (`Cliente_idCliente`)
    REFERENCES `DHespegar`.`Cliente` (`idCliente`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Reserva_Sucursal1`
    FOREIGN KEY (`Sucursal_idSucursales`)
    REFERENCES `DHespegar`.`Sucursal` (`idSucursales`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Vuelo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Vuelo` (
  `idVuelo` INT NOT NULL,
  `numero_vuelo` CHAR(6) NULL,
  `fecha_partida` DATETIME NULL,
  `fecha_estimada_llegada` DATETIME NULL,
  `origen` VARCHAR(25) NULL,
  `destino` VARCHAR(25) NULL,
  `plazas_turista` SMALLINT NULL,
  `plazas_primera_clase` SMALLINT NULL,
  PRIMARY KEY (`idVuelo`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Hotel`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Hotel` (
  `idHotel` INT NOT NULL,
  `nombre` VARCHAR(45) NULL,
  `direccion` VARCHAR(45) NULL,
  `telefono` INT NULL,
  `cantidad_habitaciones` TINYINT NULL,
  `Ciudad_idCiudad` INT NOT NULL,
  PRIMARY KEY (`idHotel`),
  INDEX `fk_Hotel_Ciudad1_idx` (`Ciudad_idCiudad` ASC) VISIBLE,
  CONSTRAINT `fk_Hotel_Ciudad1`
    FOREIGN KEY (`Ciudad_idCiudad`)
    REFERENCES `DHespegar`.`Ciudad` (`idCiudad`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Hotel_has_Reserva`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Hotel_has_Reserva` (
  `Hotel_idHotel` INT NOT NULL,
  `Reserva_idReserva` INT NOT NULL,
  `tipo_hospedaje` VARCHAR(20) NULL,
  `fecha_llegada` DATE NULL,
  `fecha_partida` DATE NULL,
  PRIMARY KEY (`Hotel_idHotel`, `Reserva_idReserva`),
  INDEX `fk_Hotel_has_Reserva_Reserva1_idx` (`Reserva_idReserva` ASC) VISIBLE,
  INDEX `fk_Hotel_has_Reserva_Hotel_idx` (`Hotel_idHotel` ASC) VISIBLE,
  CONSTRAINT `fk_Hotel_has_Reserva_Hotel`
    FOREIGN KEY (`Hotel_idHotel`)
    REFERENCES `DHespegar`.`Hotel` (`idHotel`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Hotel_has_Reserva_Reserva1`
    FOREIGN KEY (`Reserva_idReserva`)
    REFERENCES `DHespegar`.`Reserva` (`idReserva`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `DHespegar`.`Reserva_has_Vuelo`
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS `DHespegar`.`Reserva_has_Vuelo` (
  `Reserva_idReserva` INT NOT NULL,
  `Vuelo_idVuelo` INT NOT NULL,
  `clase` VARCHAR(20) NULL,
  PRIMARY KEY (`Reserva_idReserva`, `Vuelo_idVuelo`),
  INDEX `fk_Reserva_has_Vuelo_Vuelo1_idx` (`Vuelo_idVuelo` ASC) VISIBLE,
  INDEX `fk_Reserva_has_Vuelo_Reserva1_idx` (`Reserva_idReserva` ASC) VISIBLE,
  CONSTRAINT `fk_Reserva_has_Vuelo_Reserva1`
    FOREIGN KEY (`Reserva_idReserva`)
    REFERENCES `DHespegar`.`Reserva` (`idReserva`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Reserva_has_Vuelo_Vuelo1`
    FOREIGN KEY (`Vuelo_idVuelo`)
    REFERENCES `DHespegar`.`Vuelo` (`idVuelo`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
